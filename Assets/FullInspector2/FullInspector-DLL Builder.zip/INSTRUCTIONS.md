# Using Full Inspector in DLL Format

It's really easy to use Full Inspector as a DLL. Here are the instructions:

There are two ways you can do this.

## Using the precompiled DLLs

Full Inspector ships with DLLs that are already built for you. You can use them by opening `FullInspector2/FullInspector-DLL Builder.zip` and moving the DLLs inside of the `DLLs` subfolder of that package into the `FullInspector2` directory. You'll also need to delete the `FullInspector2/Core` and `FullInspector2/Modules` folders.

## Building the DLLs manually

You can also build the Full Inspector DLLs yourself if you wish. The builder is included as a set of csproj files and a solution. These files are also included in `FullInspector2/FullInspector-DLL Builder.zip`.

Assuming that the standard Unity project looks like this:

```
Assets\*
Library\*
```

unzip the project files so that it is next to assets, like so:

```
Assets\*
Library\*
FullInspector-DLL-ProjFiles\*
```

Before you open up the solution file, please open up `FullInspector-DLL-ProjFiles\CommonData.csproj` and update line 5 (`UnityInstallFolder`) to the path of your Unity installation editor folder.

Next, open `FullInspector-DLL-ProjFiles\FullInspector.sln` and build it. If you encounter errors about missing types, rebuild once more. If you encounter errors after that, submit a bug report.

You will then find the DLL files at `FullInspector-DLL-ProjFiles\DLLs`.

### Helper Batch Script for Building the DLLs

If you're making modifications to Full Inspector but are using it in a separate project in DLL format, here is an example batch script that will automatically build it as a DLL and then copy it over to your target project.

```batch
@echo off

REM Setup variables
set FI2_SLN="C:\Users\jacob\Full Inspector\FullInspector-DLL-ProjFiles\FullInspector.sln"
set MSBUILD_DIR="C:\Program Files (x86)\MSBuild\12.0\Bin\MSBuild.exe"
set BUILD_DLL_DIR="C:\Users\jacob\Full Inspector\FullInspector-DLL-ProjFiles\DLLs"
set OUTPUT_DLL_DIR="C:\Users\jacob\Game\Assets\External\FullInspector2\"

REM Build it twice to avoid any circular dependency issues
%MSBUILD_DIR% %FI2_SLN%
%MSBUILD_DIR% %FI2_SLN%

REM Copy the DLL files over
robocopy /S %BUILD_DLL_DIR% %OUTPUT_DLL_DIR%
```