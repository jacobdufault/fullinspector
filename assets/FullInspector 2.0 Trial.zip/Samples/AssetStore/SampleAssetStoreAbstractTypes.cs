﻿using System;
using System.Collections.Generic;

namespace FullInspector.Samples.AssetStore {

    public interface IInterface { }

    [Serializable]
    public class Implementation1 : IInterface {
        public int ValueA;
    }

    [Serializable]
    public class Implementation2 : IInterface {
        public string ValueB;
    }

    public class SampleAssetStoreAbstractTypes : BaseBehavior<BinaryFormatterSerializer> {

        public List<IInterface> Interfaces;
    }

}