﻿using System.Collections.Generic;
using UnityEngine;

namespace FullInspector.Samples.AssetStore {
    public class SampleAssetStoreDictionary :
        BaseBehavior<BinaryFormatterSerializer> {

        public Dictionary<string, GameObject> LabeledGameObjects;
    }
}