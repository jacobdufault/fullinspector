﻿using System;
using UnityEngine;

namespace FullInspector.Samples.AssetStore {

    [Serializable]
    public class MyGenericType<T> {
        public T Value;
    }

    public class SampleAssetStoreGenerics :
        BaseBehavior<BinaryFormatterSerializer> {

        public MyGenericType<bool> GenericBool;
        public MyGenericType<float> GenericFloat;
        public MyGenericType<GameObject> GenericObject;
    }

}