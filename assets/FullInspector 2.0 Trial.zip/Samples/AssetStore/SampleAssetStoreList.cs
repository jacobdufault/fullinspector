﻿using System.Collections.Generic;
using UnityEngine;

namespace FullInspector.Samples.AssetStore {
    public class SampleAssetStoreList : BaseBehavior<JsonNetSerializer> {
        public List<GameObject> GameObjects;
        public Transform[] Transforms;
    }
}