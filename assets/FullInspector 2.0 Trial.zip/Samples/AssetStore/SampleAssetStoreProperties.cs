﻿namespace FullInspector.Samples.AssetStore {
    public class SampleAssetStoreProperties : BaseBehavior<JsonNetSerializer> {
        public int MyProperty { get; private set; }
    }
}