﻿using System;
using UnityEngine;

namespace FullInspector.Samples.AssetStore {

    [Serializable]
    public struct MyStruct {
        public int A;
        public string B;
        public GameObject GameObject;
        public Transform Transform;
        public Collider Collider;
    }

    public class SampleAssetStoreStructs : BaseBehavior<BinaryFormatterSerializer> {

        public MyStruct Struct;
    }

}