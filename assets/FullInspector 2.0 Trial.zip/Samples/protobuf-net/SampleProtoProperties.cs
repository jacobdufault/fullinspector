﻿using ProtoBuf;

namespace FullInspector.Samples.ProtoBufNet {
    public class SampleProtoProperties : BaseBehavior<ProtoBufNetSerializer> {
        [ProtoContract]
        public struct Container {
            [ProtoMember(1)]
            public int SubValue { get; set; }
        }

        public int Value { get; set; }
        public Container ContainedValue { get; set; }
    }
}