﻿using System;

namespace FullInspector.Samples.BinaryFormatterSample {
    public class SampleBinaryFormatterStruct : BaseBehavior<BinaryFormatterSerializer> {
        [Serializable]
        public struct MyStruct {
            public int A;
            public float B;
            public string C;
        }

        public MyStruct StructValue;
    }
}