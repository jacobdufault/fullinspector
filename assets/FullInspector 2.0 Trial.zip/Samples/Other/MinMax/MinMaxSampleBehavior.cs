﻿namespace FullInspector.Samples.MinMaxSample {
    public class MinMaxSampleBehavior : BaseBehavior<JsonNetSerializer> {
        public class Constants0_150 : IMinMaxConstants {
            public int Min {
                get { return 0; }
            }

            public int Max {
                get { return 150; }
            }
        }

        public MinMax<Constants0_150> Value;
    }
}