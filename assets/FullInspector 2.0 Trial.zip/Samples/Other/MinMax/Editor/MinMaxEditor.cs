﻿using UnityEditor;
using UnityEngine;

namespace FullInspector.Samples.MinMaxSample {
    [CustomPropertyEditor(typeof(MinMax<>))]
    public class MinMaxEditor<TConstants> : PropertyEditor<MinMax<TConstants>>
        where TConstants : IMinMaxConstants, new() {

        private static TConstants _constants = new TConstants();

        public override MinMax<TConstants> Edit(Rect region, GUIContent label, MinMax<TConstants> element) {
            return new MinMax<TConstants>() {
                Value = EditorGUI.IntSlider(region, label, element.Value, _constants.Min, _constants.Max)
            };
        }

        public override float GetElementHeight(GUIContent label, MinMax<TConstants> element) {
            return EditorStyles.largeLabel.CalcHeight(label, 100);
        }
    }
}