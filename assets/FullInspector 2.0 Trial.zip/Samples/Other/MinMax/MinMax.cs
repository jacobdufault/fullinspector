﻿using Newtonsoft.Json;
using System;

namespace FullInspector.Samples.MinMaxSample {
    public interface IMinMaxConstants {
        int Min { get; }
        int Max { get; }
    }

    [JsonObject(MemberSerialization.OptIn)]
    public struct MinMax<TConstants> where TConstants : IMinMaxConstants, new() {
        private static IMinMaxConstants _contants = new TConstants();

        [JsonProperty]
        public int _value;

        public int Value {
            get {
                return _value;
            }
            set {
                if (value < _contants.Min && value > _contants.Max) {
                    throw new ArgumentOutOfRangeException();
                }

                _value = value;
            }
        }
    }
}