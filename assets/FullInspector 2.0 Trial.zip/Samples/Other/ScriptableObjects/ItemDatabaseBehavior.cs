﻿namespace FullInspector.Samples.ItemDatabase {
    public class ItemDatabaseBehavior : BaseBehavior<JsonNetSerializer> {
        public ItemDatabaseSample ScriptableObject;
    }
}