﻿namespace FullInspector.Samples.Button {
    public interface IButton {
        void Act();
    }
}