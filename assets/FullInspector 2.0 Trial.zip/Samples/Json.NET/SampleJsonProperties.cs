﻿using Newtonsoft.Json;

namespace FullInspector.Samples.JsonNet {
    public class SampleJsonProperties : BaseBehavior<JsonNetSerializer> {
        [JsonObject(MemberSerialization.OptIn)]
        public struct Container {
            [JsonProperty]
            public int SubValue { get; set; }
        }

        public int Value { get; set; }
        public Container ContainedValue { get; set; }
    }
}