﻿using Newtonsoft.Json;

namespace FullInspector.Samples.JsonNet {
    public class SampleJsonStruct : BaseBehavior<JsonNetSerializer> {
        [JsonObject(MemberSerialization.OptIn)]
        public struct MyStruct {
            [JsonProperty]
            public int A;
            [JsonProperty]
            public float B;
            [JsonProperty]
            public string C;
        }

        public MyStruct StructValue;
    }
}