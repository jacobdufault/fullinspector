﻿using Newtonsoft.Json;
using System.Collections.Generic;
using UnityEngine;

namespace FullInspector.Samples.JsonNet {
    public class SampleJsonDictionaries : BaseBehavior<JsonNetSerializer> {
        [JsonObject(MemberSerialization.OptIn)]
        public struct Container {
            [JsonProperty]
            public Dictionary<string, GameObject> StrGoDict;
        }

        public Dictionary<string, string> StrStrDict;

        public enum Enum { ValueA, ValueB, ValueC };
        public Dictionary<Enum, Transform> EnumTransformDict;
    }
}